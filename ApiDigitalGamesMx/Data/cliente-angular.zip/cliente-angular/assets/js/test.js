"use strict";

// function hola2(){
//   alert("hola mundo");
// }

var App = function () {
  var _initMessage = function () {
    //alert("hola mundo");
  }

  return {
    init: function () {
      _initMessage();
    }
  }
}();
